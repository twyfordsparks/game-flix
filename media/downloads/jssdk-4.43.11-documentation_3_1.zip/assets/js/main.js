var jQuery = require('jquery');
var Prism = require('prismjs');
var currentClass;
require('prismjs/components/prism-javascript');
require('prismjs/plugins/normalize-whitespace/prism-normalize-whitespace');
require('imports-loader?jQuery=jquery!jquery-scrollintoview/jquery.scrollintoview');
require('iframe-resizer/js/iframeResizer.contentWindow.min');
require('prismjs/themes/prism.css');
require('bootstrap/dist/css/bootstrap.min.css');
require('../css/index.css');

/**
 * @return {Boolean}
 */
function isIFramed() {
    return 'parentIFrame' in window;
}

/**
 * @param {String} url
 * @return {String}
 */
function getHashFromUrl(url) {
    var match = (/#.+$/i).exec(url);
    return match ? match[0] : null;
}

/**
 * @param {String} url
 * @return {Boolean}
 */
function isAbsoluteUrl(url) {
    return (/^\w+?:\/{2,3}/i).test(url);
}

/**
 * @param {String} url
 * @return {Boolean}
 */
function isRelativePath(url) {
    return typeof url === 'string' && ['.', '/'].indexOf(url[0]) !== -1;
}

/**
 * @param {String} href
 * @return {Boolean}
 */
function isAnchor(href) {
    return typeof href === 'string' && href[0] === '#';
}

function resetScroll() {
    if (isIFramed()) {
        window.parentIFrame.scrollTo(0, 0);
    } else {
        document.body.scrollTop = 0;
    }
}

/**
 * @param {String} url
 * @return {String}
 */
function getClassNameFromUrl(url) {
    var matches = /([-\w.]+)\.html/i.exec(url);
    return matches[1];
}

/**
 * @param {String} className
 * @return {String}
 */
function getUrlFromClassName(className) {
    return '../classes/' + className.replace('#', '') + '.html';
}

/**
 * Temporally highlight the element.
 * @param {String} selector
 */
function highlightElement(selector) {
    var elem = jQuery(selector);
    elem.addClass('focused');
    setTimeout(function() {
        elem.addClass('focused-fadeout');
        setTimeout(function() {
            if (elem) {
                elem.removeClass('focused-fadeout').removeClass('focused');
            }
        }, 2000);
    });
}

/**
 * @param {String} selector anchor's name
 */
function scrollToAnchor(selector) {
    selector = selector.indexOf('#') === -1 ? '#' + selector : selector;
    if (isIFramed()) {
        window.parentIFrame.moveToAnchor(selector);
    } else {
        jQuery(selector).scrollintoview({direction: 'y'});
    }
    highlightElement(selector);
}

function applySyntaxHighlight() {
    try {
        Prism.highlightAll();
    } catch (err) {
        console.error('The syntax highlight couldn\'t be re-applied. Maybe the lib was not loaded?');
    }
}

/**
 * @param {*} msg
 */
function sentMessageToParent(msg) {
    window.parentIFrame.sendMessage(msg, '*');
}

/**
 * @param {String} pageUrl
 */
function updateParentWindowHash(pageUrl) {
    var className = getClassNameFromUrl(pageUrl);
    sentMessageToParent({type: 'classLoaded', className: className});
}

/**
 * @param {String} html
 */
function updateMainContent(html) {
    var contentHtml = /<!-- Main content -->([\s\S]*)<!-- End of main content -->/m.exec(html)[0];
    jQuery('#main').html(contentHtml);
}

/**
 * @param {String} html
 * @param {String} linkHref
 */
function updateSidebar(html, linkHref) {
    var currentSidebar = jQuery('#sidebar nav ul').first(),
        currentActiveClassNode, newClassNode, currentClassNode;

    currentActiveClassNode = currentSidebar.find('li.class-node.active').first();
    currentActiveClassNode.children('ul').remove();
    currentActiveClassNode.removeClass('active');
    currentActiveClassNode.closest('li.module-node').addClass('collapsed');

    newClassNode = jQuery(html).find('li.class-node a[href="' + linkHref + '"]').first().parent();
    currentClassNode = currentSidebar.find('li.class-node a[href="' + linkHref + '"]').first().parent();
    currentClassNode.replaceWith(newClassNode);
    newClassNode.closest('li.module-node').removeClass('collapsed');
}

/**
 * @param {String} responseText
 * @param {String} fullHrefLoaded
 */
function handleSuccessfullyLoadedPage(responseText, fullHrefLoaded) {
    var hrefParts = fullHrefLoaded.split('#'),
        href = hrefParts[0],
        anchor = hrefParts[1] || '';
    updateMainContent(responseText);
    updateSidebar(responseText, href);
    applySyntaxHighlight();
    if (isIFramed()) {
        updateParentWindowHash(href);
        if (anchor) {
            scrollToAnchor(anchor);
        } else {
            resetScroll();
        }
    }
}

/**
 * @param {String} pageUrl Loads an html page and replaces the current content
 */
function loadPage(pageUrl) {
    if (!pageUrl || currentClass === getClassNameFromUrl(pageUrl)) {
        return;
    }
    jQuery.get({
        url: pageUrl,
        dataType: 'html',
        success: function(response) {
            currentClass = getClassNameFromUrl(pageUrl);
            handleSuccessfullyLoadedPage(response, pageUrl);
        }
    });
}

/**
 * @param {jQuery} header
 * @return {Boolean}
 */
function isModuleHeader(header) {
    return header.hasClass('module-node');
}

/**
 * @param {jQuery} header
 * @return {Boolean}
 */
function isClassHeader(header) {
    return header.hasClass('class-node');
}

/**
 * @param {jQuery} header
 * @return {Boolean}
 */
function isNodeCollapsed(header) {
    return header.hasClass('collapsed');
}

/**
 * @param {jQuery} header
 */
function toggleNodeCollapse(header) {
    if (isNodeCollapsed(header)) {
        header.removeClass('collapsed');
    } else {
        header.addClass('collapsed');
    }
}

/**
 * @param {jQuery.Event} event
 */
function onClickModuleHeader(event) {
    var target = jQuery(event.target);
    var header = target.is('li') ? target : target.closest('li');
    if (isModuleHeader(header)) {
        toggleNodeCollapse(header);
        event.preventDefault();
    }
}

/**
 * @param {Object} event
 */
function onClickClassHeader(event) {
    var target = jQuery(event.target);
    var header = target.is('li') ? target : target.closest('li');
    var href = header.children('a').first().attr('href');
    if (isIFramed() && isClassHeader(header)) {
        event.preventDefault();
        loadPage(href);
    }
}

/**
 * @param {jQuery.Event} event
 */
function onClickClassMemberHeader(event) {
    if (isIFramed()) {
        event.preventDefault();
    }
    scrollToAnchor(event.currentTarget.hash);
}

/**
 * @param {jQuery.Event} event
 */
function onClickContentLink(event) {
    var linkNode = jQuery(event.target);
    var href = linkNode.attr('href');
    var hrefTarget = linkNode.attr('target');
    var hash;
    if (isRelativePath(href) && getClassNameFromUrl(href) === currentClass) {
        hash = getHashFromUrl(href);
        href = hash ? hash : href;
    }
    if (isAnchor(href)) {
        event.preventDefault();
        scrollToAnchor(href);
    } else if (isIFramed()) {
        event.preventDefault();
        if (!isAbsoluteUrl(href)) {
            loadPage(href);
        } else if (hrefTarget !== '_blank') {
            window.top.location = href;
        }
    }
}

function installListeners() {
    // Expand&collapse module headers and prevent follow link for modules
    jQuery('#sidebar>nav>ul').on('click', 'li.module-node', onClickModuleHeader);
    // On click class
    jQuery('#sidebar>nav>ul').on('click', 'li.class-node a', onClickClassHeader);
    // On click method or event
    jQuery('#sidebar>nav>ul').on('click', 'li.member-node a', onClickClassMemberHeader);
    // On click link in content
    jQuery('#main').on('click', 'a', onClickContentLink);
}

window.iFrameResizer = {
    messageCallback: function(msg) {
        if (msg.type === 'loadClass') {
            loadPage(getUrlFromClassName(msg.className));
        }
    },
    // This function will be called ONLY when the example is load inside an iFrame container
    readyCallback: function() {
        jQuery(function() {
            jQuery('#main-header').remove();
            jQuery('#doc>.container').removeClass('container').addClass('fluid-container');
            sentMessageToParent({type: 'ready'});
        });
    }
};

jQuery(function() {
    currentClass = getClassNameFromUrl(document.location.href);
    installListeners();
});
